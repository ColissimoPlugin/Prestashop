<?php

/**
 * Class AbstractColissimoResponse
 */
class AbstractColissimoResponse
{
    /** @var array $messages */
    public $messages;

    /** @var array $response */
    public $response;
}
