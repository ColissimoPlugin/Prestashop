<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Class AbstractColissimoResponse
 */
class AbstractColissimoResponse
{
    /** @var array $messages */
    public $messages;

    /** @var array $response */
    public $response;
}
