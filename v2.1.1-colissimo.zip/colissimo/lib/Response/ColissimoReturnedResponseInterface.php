<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Interface ColissimoReturnedResponseInterface
 */
interface ColissimoReturnedResponseInterface
{
    /**
     * @param string $responseHeader
     * @param string $responseBody
     * @return mixed
     */
    public static function buildFromResponse($responseHeader, $responseBody);
}
